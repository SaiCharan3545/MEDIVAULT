# SecureHealth - Blockchain Medical Data Sharing Platform

## Overview

SecureHealth is a blockchain-powered medical data sharing platform that enables secure patient-hospital data interactions with AI-driven search capabilities. The system allows patients to control access to their medical records while hospitals can search for relevant patient cases through an intelligent matching system. Built with privacy-first principles, the platform uses blockchain for data integrity, AI for semantic search, and a reward system for data sharing incentives.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state, React Hook Form for form state
- **Routing**: Wouter for lightweight client-side routing
- **Component Strategy**: Modular component architecture with reusable UI primitives

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with session-based authentication
- **Middleware**: Express session handling with custom logging middleware
- **Build System**: esbuild for production builds, tsx for development

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Schema Management**: Drizzle migrations with type-safe schema definitions
- **Session Storage**: Database-backed sessions using connect-pg-simple

### Authentication and Authorization
- **Authentication Method**: Session-based authentication with secure cookies
- **Password Security**: bcrypt for password hashing
- **Access Control**: Role-based access (patients vs hospitals) with data ownership verification
- **Session Management**: Secure session configuration with environment-based security settings

### Core Services

#### Blockchain Service
- **Purpose**: Ensures data integrity and immutable record keeping
- **Implementation**: Custom blockchain hash generation using SHA-256
- **Data Structure**: Patient records are hashed with deterministic blockchain-style identifiers
- **Verification**: Hash verification system for data authenticity

#### AI Search Service
- **Provider**: OpenAI GPT-5 integration for semantic medical search
- **Functionality**: Intelligent matching between search queries and patient conditions
- **Features**: Medical synonym recognition, semantic similarity analysis, relevance scoring
- **Privacy**: Search queries processed without storing sensitive patient data

#### Access Control System
- **Patient Control**: Patients define which hospitals can access their data
- **Permission Verification**: Real-time access control checks during data retrieval
- **Audit Trail**: Complete logging of all data access attempts
- **Reward System**: Automatic reward calculation for data sharing

### Data Architecture
- **Patient Records**: Comprehensive medical profiles with blockchain hashing
- **Hospital Management**: Secure hospital authentication and search capabilities
- **Access Logging**: Detailed audit trail of all data interactions
- **Revenue Tracking**: Reward system for patients sharing valuable data

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle ORM**: Type-safe database operations and migrations

### AI and Machine Learning
- **OpenAI API**: GPT-5 integration for semantic medical search and condition matching
- **Custom AI Service**: Medical terminology processing and relevance scoring

### Security and Authentication
- **bcrypt**: Password hashing and security
- **Express Session**: Session management with PostgreSQL storage

### UI and Component Libraries
- **Radix UI**: Accessible, unstyled component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography

### Development and Build Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Type safety across frontend and backend
- **React Hook Form**: Form validation and management
- **TanStack Query**: Server state management and caching

### Deployment and Runtime
- **Replit Platform**: Development environment with integrated deployment
- **Node.js**: Server runtime environment
- **WebSocket Support**: Real-time capabilities through ws library